class Circle extends Shape2D{
    private int r;//radius
    public Circle(int r){
        this.r=r;
    }
    public double findPerimeter(){
        return 2*Math.PI*r;
    }
    public double findArea(){
        return Math.PI*r*r;
    }
}