class Cuboid extends Rectangle{
    private int H;//height
    public Cuboid(int l,int w,int H){
        super(l,w);
        this.H=H;
    }
    public double getVolume(){
        return super.findArea()*H;
    }
}