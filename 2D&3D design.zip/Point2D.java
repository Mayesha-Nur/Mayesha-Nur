class Point2D{
    private int x;
    private int y;
    public Point2D(int x,int y){
        this.x=x;
        this.y=y;
    }
    public double findEuclidian(Point2D point){
        int X=this.x-point.x;
        int Y=this.y-point.y;
        return Math.sqrt(X*X + Y*Y);
    }
}