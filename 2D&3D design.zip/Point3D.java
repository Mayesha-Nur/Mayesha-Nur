class Point3D extends Point2D{
    private int z;
    public Point3D(int x,int y,int z){
        super(x,y);
        this.z=z;
    }
    public double findEuclidian(Point3D point){
        int X=this.x-point.x;
        int Y=this.y-point.y;
        int Z=this.z-point.z;
        return  Math.sqrt(X*X + Y*Y + Z*Z);
    }
}