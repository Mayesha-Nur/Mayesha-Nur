class Rectangle extends Shape2D{
    private int l;//length
    private int w;//width
    public Rectangle(int l,int w){
        this.l=l;
        this.w=w;
    }
    public double findPerimeter(){
        return 2*(l+w);
    }
    public double findArea(){
        return l*w;
    }
}