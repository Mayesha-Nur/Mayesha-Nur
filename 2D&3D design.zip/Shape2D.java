class Shape2D{
    public double findPerimeter();
    public double findArea();
}