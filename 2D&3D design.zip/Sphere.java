class Sphere extends Circle{
    public Sphere(int r){
        super(r);
    }
    public double getVolume(){
        return (4.0/3.0)*Math.PI*r*r*r;
    }
}
